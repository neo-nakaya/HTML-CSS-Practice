alert("JavaScriptを試してみましょう！");
